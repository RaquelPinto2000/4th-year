package commInfra;

public class MessageType {

}

package commInfra;

public class ClientCom {

	public ClientCom() {
		// TODO Auto-generated constructor stub
	}

}

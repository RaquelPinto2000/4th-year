package commInfra;

import java.io.Serializable;

public class Message implements Serializable {

	public Message() {
		// TODO Auto-generated constructor stub
	}

}

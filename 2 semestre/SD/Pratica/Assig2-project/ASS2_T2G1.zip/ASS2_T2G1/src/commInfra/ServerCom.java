package commInfra;

public class ServerCom {

	public ServerCom() {
		// TODO Auto-generated constructor stub
	}

}

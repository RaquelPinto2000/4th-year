package clientSide.entities;

public interface StudentCloning {

}

package clientSide.stubs;

public class KitchenStub {

	public KitchenStub() {
		// TODO Auto-generated constructor stub
	}

}

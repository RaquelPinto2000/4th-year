package clientSide.entities;

public interface WaiterCloning {

}

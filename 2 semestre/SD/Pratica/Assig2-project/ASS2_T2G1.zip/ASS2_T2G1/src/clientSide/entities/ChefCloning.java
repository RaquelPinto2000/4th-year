package clientSide.entities;

public interface ChefCloning {

}

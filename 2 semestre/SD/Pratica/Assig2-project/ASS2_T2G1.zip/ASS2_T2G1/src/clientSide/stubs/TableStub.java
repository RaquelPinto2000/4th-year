package clientSide.stubs;

public class TableStub {

	public TableStub() {
		// TODO Auto-generated constructor stub
	}

}

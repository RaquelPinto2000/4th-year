package clientSide.stubs;

public class BarStub {

	public BarStub() {
		// TODO Auto-generated constructor stub
	}

}

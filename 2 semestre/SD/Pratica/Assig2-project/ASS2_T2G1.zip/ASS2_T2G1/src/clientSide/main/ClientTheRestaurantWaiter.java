package clientSide.main;

public class ClientTheRestaurantWaiter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

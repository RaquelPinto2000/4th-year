package clientSide.stubs;

public class GeneralReposStub {

	public GeneralReposStub() {
		// TODO Auto-generated constructor stub
	}

}

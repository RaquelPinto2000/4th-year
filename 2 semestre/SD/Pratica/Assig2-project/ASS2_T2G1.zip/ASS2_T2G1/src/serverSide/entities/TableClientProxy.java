package serverSide.entities;

public class TableClientProxy {

	public TableClientProxy() {
		// TODO Auto-generated constructor stub
	}

}

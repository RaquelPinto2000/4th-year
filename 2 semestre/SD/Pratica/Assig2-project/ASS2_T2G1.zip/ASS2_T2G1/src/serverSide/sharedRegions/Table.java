package serverSide.sharedRegions;

public class Table {

	public Table() {
		// TODO Auto-generated constructor stub
	}

}

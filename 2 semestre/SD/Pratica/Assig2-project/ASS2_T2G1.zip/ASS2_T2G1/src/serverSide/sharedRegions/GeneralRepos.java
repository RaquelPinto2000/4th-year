package serverSide.sharedRegions;

public class GeneralRepos {

	public GeneralRepos() {
		// TODO Auto-generated constructor stub
	}

}

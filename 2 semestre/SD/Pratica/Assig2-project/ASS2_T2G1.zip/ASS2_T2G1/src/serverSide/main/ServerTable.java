package serverSide.main;

public class ServerTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

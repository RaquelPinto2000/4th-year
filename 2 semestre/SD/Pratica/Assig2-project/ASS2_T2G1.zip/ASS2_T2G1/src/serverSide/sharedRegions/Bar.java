package serverSide.sharedRegions;

public class Bar {

	public Bar() {
		// TODO Auto-generated constructor stub
	}

}

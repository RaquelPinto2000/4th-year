package serverSide.sharedRegions;

public class Kitchen {

	public Kitchen() {
		// TODO Auto-generated constructor stub
	}

}

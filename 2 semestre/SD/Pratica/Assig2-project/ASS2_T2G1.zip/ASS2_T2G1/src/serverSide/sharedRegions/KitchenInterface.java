package serverSide.sharedRegions;

public interface KitchenInterface {

}

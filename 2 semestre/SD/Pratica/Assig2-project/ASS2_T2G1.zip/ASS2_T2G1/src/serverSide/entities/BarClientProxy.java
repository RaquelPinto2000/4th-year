package serverSide.entities;

public class BarClientProxy {

	public BarClientProxy() {
		// TODO Auto-generated constructor stub
	}

}

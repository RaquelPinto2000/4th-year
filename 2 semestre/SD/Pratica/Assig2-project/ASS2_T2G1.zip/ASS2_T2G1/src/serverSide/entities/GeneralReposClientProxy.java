package serverSide.entities;

public class GeneralReposClientProxy {

	public GeneralReposClientProxy() {
		// TODO Auto-generated constructor stub
	}

}

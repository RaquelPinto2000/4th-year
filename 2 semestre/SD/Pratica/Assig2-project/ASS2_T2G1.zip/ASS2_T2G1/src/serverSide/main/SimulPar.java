package serverSide.main;

public final class SimulPar {

}

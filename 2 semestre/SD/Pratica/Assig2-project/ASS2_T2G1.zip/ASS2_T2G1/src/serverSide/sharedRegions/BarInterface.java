package serverSide.sharedRegions;

public interface BarInterface {

}

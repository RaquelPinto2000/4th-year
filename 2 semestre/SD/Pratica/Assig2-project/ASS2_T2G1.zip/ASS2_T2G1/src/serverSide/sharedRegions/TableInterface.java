package serverSide.sharedRegions;

public interface TableInterface {

}

package serverSide.entities;

public class KitchenClientProxy {

	public KitchenClientProxy() {
		// TODO Auto-generated constructor stub
	}

}

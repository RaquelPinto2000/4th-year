/**
 *  Communication infrastructure of the Riddles Play.
 *
 *  Communication is based on message passing over sockets using the UDP protocol.
 */

package commInfra;

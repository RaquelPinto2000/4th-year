kubectl create secret generic app-secret --from-file=secret   -n diving-into-k3s

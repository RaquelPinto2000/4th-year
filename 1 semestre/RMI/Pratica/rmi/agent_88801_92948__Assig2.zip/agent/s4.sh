javac jClientC4.java
read -p "Press any key to resume ..."
java jClientC4  --pos 1 --robname jClient4 "$@"


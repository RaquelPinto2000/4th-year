javac jClientC2.java
java jClientC2  --pos 1 --robname jClient2 "$@"

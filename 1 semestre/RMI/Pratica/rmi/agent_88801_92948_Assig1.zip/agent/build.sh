#!/bin/bash

# How to build your project

# Possibility for cpp agents
# make mainC1 
# make mainC2 
# make mainC3 

# Possibility for java agents
javac jClientC1.java
javac jClientC2.java
#javac jClientC3.java

# Possibility for python agents
# nothing



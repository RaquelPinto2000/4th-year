java jClientC1  --pos 1 --robname jClient1 "$@"

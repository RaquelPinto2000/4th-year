javac jClientC3.java
java jClientC3  --pos 1 --path mapa.txt --robname jClient2 -n 3 "$@"
